 Persona Example:
    
    Name: Kim Cheolsu
    Age: 25
    Occupation: University Student (Cyber Security)
    
    Goals:
    - Find reliable information for academic purposes
    - Gather hobby-related information
    
    Needs:
    - Fast and accurate search functionality
    - Trustworthy content
    - Easy document editing

